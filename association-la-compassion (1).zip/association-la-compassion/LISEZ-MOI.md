# Site de l'Association La Compassion — guide simple

## Modifier
- Textes : ouvrir le fichier .html avec le Bloc-notes, changer le texte, enregistrer.
- Chercher `[À CONFIRMER]` ou `[...]` : ce sont les informations à fournir. Tout le site doit être vérifié avant publication.
- Menu, pied de page, téléphone, liens réseaux sociaux : fichier `js/main.js` (début du fichier).
- Chiffres d'impact : `index.html`, remplacer `+ [NOMBRE]`.
- Actualités : `news.html`, ajouter une ligne dans la liste NEWS.
- Photos : déposer dans `images/` (JPG, moins de 300 Ko), puis `<img src="images/nom.jpg" alt="description">`. Uniquement des photos dont l'association détient les droits, avec accord des personnes.
- Documents PDF : déposer dans `documents/` et ajouter le lien dans `transparency.html`.

## Publier gratuitement (GitHub Pages — recommandé)
1. Créer un compte sur github.com. 2. « New repository », nom `association-la-compassion`, public.
3. « Add file » > « Upload files » : glisser tout le contenu du dossier, puis « Commit ».
4. « Settings » > « Pages » > Source : branche `main`, dossier `/ (root)` > Save. L'adresse apparaît après 1 à 2 minutes.

## Alternatives
- Cloudflare Pages ou Netlify : créer un compte, « Add new site » > « Deploy manually / Upload », glisser le dossier.

## Domaine personnalisé
Acheter un nom de domaine, puis dans Pages (ou Netlify/Cloudflare) > « Custom domain », saisir le domaine et créer chez le registraire les enregistrements DNS indiqués. Ensuite, remplacer `VOTRE-DOMAINE` dans `robots.txt` et `sitemap.xml`.

## Avant publication
- [ ] Tous les `[À CONFIRMER]` remplis ou supprimés  - [ ] Coordonnées de paiement vérifiées
- [ ] Photos avec droits et consentements  - [ ] Documents réellement disponibles seulement
- [ ] Test sur téléphone et ordinateur  - [ ] Soumettre sitemap.xml à Google Search Console
- [ ] Version anglaise : à produire, le bouton EN est désactivé
